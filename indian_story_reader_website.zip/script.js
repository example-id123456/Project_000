const chapters = [
  {
    title: "अध्याय 1 — आरंभ",
    meta: "लगभग 3 मिनट का पठन",
    content: `
      <p>बहुत समय पहले, भारत के एक छोटे से गाँव में आरव नाम का एक जिज्ञासु युवक रहता था। गाँव के चारों ओर हरे-भरे खेत, पुराने बरगद के पेड़ और दूर दिखाई देता एक शांत पहाड़ था।</p>
      <p>आरव को अपने दादा से पुरानी कथाएँ सुनना बहुत पसंद था। दादा अक्सर कहते, “सच्ची यात्रा पैरों से नहीं, मन से शुरू होती है।” यह बात आरव के मन में बस गई थी।</p>
      <div class="quote">“जहाँ जिज्ञासा होती है, वहीं से ज्ञान की राह खुलती है।”</div>
      <p>एक सुबह सूरज की पहली किरणों के साथ आरव ने गाँव छोड़कर पहाड़ की ओर जाने का निश्चय किया। उसके पास एक छोटा सा थैला, पानी की बोतल और दादा का दिया हुआ दीपक था।</p>
      <p>उसे नहीं पता था कि आगे क्या मिलेगा, लेकिन उसके मन में डर से अधिक उत्साह था। यही उसकी यात्रा का पहला कदम था।</p>
    `
  },
  {
    title: "अध्याय 2 — यात्रा",
    meta: "लगभग 4 मिनट का पठन",
    content: `
      <p>पहाड़ की राह में आरव को एक पुराना मंदिर मिला। मंदिर के आँगन में एक साधु शांत बैठकर दीपक जला रहे थे।</p>
      <p>आरव ने प्रणाम किया और पूछा, “मुझे आगे किस रास्ते पर जाना चाहिए?” साधु मुस्कुराए और बोले, “रास्ता वही सही है जो तुम्हें भीतर से बेहतर बनाए।”</p>
      <p>उन्होंने आरव को एक छोटी सी घंटी दी और कहा कि जब भी मन में भ्रम हो, कुछ पल रुककर अपनी आवाज़ सुनना।</p>
      <div class="quote">“बाहर की राह से पहले भीतर की राह पहचानो।”</div>
      <p>आरव ने धन्यवाद दिया और आगे बढ़ गया। रास्ता कठिन था, लेकिन हर कदम के साथ उसका आत्मविश्वास बढ़ता गया।</p>
    `
  },
  {
    title: "अध्याय 3 — सीख",
    meta: "लगभग 4 मिनट का पठन",
    content: `
      <p>शाम तक आरव पहाड़ के एक ऊँचे स्थान पर पहुँच गया। वहाँ उसे एक छोटा सा गाँव दिखाई दिया, जहाँ लोग पानी की कमी से परेशान थे।</p>
      <p>आरव ने देखा कि पहाड़ से एक छोटी जलधारा नीचे की ओर बह रही थी, लेकिन रास्ते में पत्थर जमा होने के कारण पानी गाँव तक नहीं पहुँच रहा था।</p>
      <p>उसने गाँव वालों के साथ मिलकर रास्ता साफ किया। थोड़ी मेहनत के बाद पानी फिर से बहने लगा। गाँव के लोगों के चेहरों पर खुशी देखकर आरव समझ गया कि असली ज्ञान वही है जो किसी के काम आए।</p>
      <div class="quote">“सीख तब पूरी होती है, जब वह किसी और के जीवन में उजाला लाए।”</div>
    `
  },
  {
    title: "अध्याय 4 — वापसी",
    meta: "लगभग 3 मिनट का पठन",
    content: `
      <p>अगली सुबह आरव अपने गाँव लौटने लगा। उसके हाथ में वही छोटा दीपक था, लेकिन मन पहले से अधिक उजला था।</p>
      <p>दादा ने उसे देखते ही पूछा, “क्या तुम्हें वह मिल गया जिसकी तलाश थी?” आरव मुस्कुराया और बोला, “हाँ दादा, मुझे समझ आया कि यात्रा का असली उद्देश्य खुद को बदलना और दूसरों के काम आना है।”</p>
      <p>दादा ने उसके सिर पर हाथ रखा। उस शाम गाँव के चौपाल में आरव ने अपनी पूरी कहानी सबको सुनाई।</p>
      <div class="quote">“ज्ञान का दीपक जितना बाँटो, उतना ही अधिक प्रकाश देता है।”</div>
      <p>उस दिन से आरव गाँव के बच्चों को पढ़ाने लगा। उसकी यात्रा खत्म नहीं हुई थी; वह एक नई कहानी की शुरुआत बन गई थी।</p>
    `
  }
];

let currentChapter = 0;
let fontSize = Number(localStorage.getItem("readerFontSize")) || 22;

const chapterTitle = document.getElementById("chapterTitle");
const chapterMeta = document.getElementById("chapterMeta");
const storyText = document.getElementById("storyText");
const chapterCount = document.getElementById("chapterCount");
const progressBar = document.getElementById("progressBar");
const chaptersButtons = document.querySelectorAll(".chapter");

function renderChapter(index) {
  currentChapter = index;
  const chapter = chapters[index];

  chapterTitle.textContent = chapter.title;
  chapterMeta.textContent = chapter.meta;
  storyText.innerHTML = chapter.content;
  chapterCount.textContent = `${index + 1} / ${chapters.length}`;

  chaptersButtons.forEach((button, i) => {
    button.classList.toggle("active", i === index);
  });

  document.documentElement.style.setProperty("--reader-size", `${fontSize}px`);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function setFontSize(nextSize) {
  fontSize = Math.max(16, Math.min(30, nextSize));
  storyText.style.setProperty("--reader-size", `${fontSize}px`);
  localStorage.setItem("readerFontSize", fontSize);
}

document.getElementById("fontIncrease").addEventListener("click", () => {
  setFontSize(fontSize + 1);
});

document.getElementById("fontDecrease").addEventListener("click", () => {
  setFontSize(fontSize - 1);
});

document.getElementById("themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("readerDarkMode", document.body.classList.contains("dark"));
});

document.getElementById("prevBtn").addEventListener("click", () => {
  if (currentChapter > 0) renderChapter(currentChapter - 1);
});

document.getElementById("nextBtn").addEventListener("click", () => {
  if (currentChapter < chapters.length - 1) renderChapter(currentChapter + 1);
});

chaptersButtons.forEach((button) => {
  button.addEventListener("click", () => {
    renderChapter(Number(button.dataset.chapter));
  });
});

window.addEventListener("scroll", () => {
  const scrollTop = window.scrollY;
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  const progress = scrollable > 0 ? (scrollTop / scrollable) * 100 : 0;
  progressBar.style.width = `${Math.min(progress, 100)}%`;
});

if (localStorage.getItem("readerDarkMode") === "true") {
  document.body.classList.add("dark");
}

storyText.style.setProperty("--reader-size", `${fontSize}px`);
